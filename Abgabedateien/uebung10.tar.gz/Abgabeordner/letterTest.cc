#include "letterfrequencies.hh"
#include "frequencysource.hh"

int main(int argc, char *argv[]) {
  //print_frequencies(get_frequencies());
  return 0;
}