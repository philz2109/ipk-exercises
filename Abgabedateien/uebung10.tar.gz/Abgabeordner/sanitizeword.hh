#ifndef SANITIZEWORD_HH
#define SANITIZEWORD_HH

#include <string>

std::string sanitize_word(const std::string& s);

#endif  // SANITIZEWORD_HH
